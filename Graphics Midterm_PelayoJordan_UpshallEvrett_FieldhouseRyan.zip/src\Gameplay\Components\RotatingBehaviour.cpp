#include "Gameplay/Components/RotatingBehaviour.h"

#include "Gameplay/GameObject.h"

#include "Utils/ImGuiHelper.h"
#include "Utils/JsonGlmHelpers.h"

void RotatingBehaviour::Update(float deltaTime) {
	timer += deltaTime;
	if (timer >= 2.f)
	{
		right = !right;
		timer = 0.f;
	}
	
	if (right)
	{
		GetGameObject()->SetPostion(GetGameObject()->GetPosition() + (glm::vec3(0.f, 0.05f, 0.f)));
	}
	else
	{
		GetGameObject()->SetPostion(GetGameObject()->GetPosition() - (glm::vec3(0.f, 0.05f, 0.f)));
	}
}

void RotatingBehaviour::RenderImGui() {
	LABEL_LEFT(ImGui::DragFloat3, "Speed", &RotationSpeed.x);
}

nlohmann::json RotatingBehaviour::ToJson() const {
	return {
		{ "speed", RotationSpeed }
	};
}

RotatingBehaviour::Sptr RotatingBehaviour::FromJson(const nlohmann::json& data) {
	RotatingBehaviour::Sptr result = std::make_shared<RotatingBehaviour>();
	result->RotationSpeed = JsonGet(data, "speed", result->RotationSpeed);
	return result;
}
